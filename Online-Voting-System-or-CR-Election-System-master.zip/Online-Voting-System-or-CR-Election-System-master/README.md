# Online-Voting-System-or-CR-Election-System
SE-133 Software Development project by Manas PRajapati in C++


Protected By Admin Password.
      
    Password: mypass

OnlineVotingSystem.cpp 

    That is the main c++ file of my project.

ID.txt

    That is like a voterlist where all student's(who can perticipate this election) ID must be written.
    
Name.txt

    Software read this file and compair with ID and then show the valid voter name.

VoteDoneBy.txt

    Those Voter who have done his vote, their ID will written in this text file.
    
VoteDetails.txt

    Realtime Vote details will collected here (voter ID + candedate name). And only admin can see this.
